import torch as th
from state import SimulationState
from constants import *

class DebugLogger:
    def __init__(self, log_interval: int = 100):
        self.log_interval = log_interval
        self.infection_log = []
        self.reproduction_log = []
        
    def log_reproduction(self, state: SimulationState, t: int):
        """Logs information about reproduction"""
        if t % self.log_interval != 0:
            return
            
        n = state.pop_size
        if n == 0:
            return
            
        # Analysis of parent genotypes and offspring
        pending = state.pending_offspring_count
        if pending > 0:
            # Genotypes of pending offspring
            pending_genotypes = state.pending_offspring_chrom_a[:pending].sum(dim=1)
            
            semel_pending = (pending_genotypes == 2).sum().item()
            itero_pending = (pending_genotypes == 0).sum().item()
            hetero_pending = (pending_genotypes == 1).sum().item()
            
            print(f"\n=== REPRODUCTION t={t} ===")
            print(f"Pending offspring: {pending}")
            print(f"  Semelparous: {semel_pending}")
            print(f"  Iteroparous: {itero_pending}")
            print(f"  Heterozygous: {hetero_pending}")
            
            # Check parent genotypes
            self.check_parent_genotypes(state, pending)
    
    def check_parent_genotypes(self, state: SimulationState, pending_count: int):
        """Checks correspondence between parent and offspring genotypes"""
        mother_ids = state.pending_offspring_mother_id[:pending_count]
        
        for i, mother_id in enumerate(mother_ids):
            mother_idx = th.where(state.animal_ids == mother_id)[0]
            if len(mother_idx) == 0:
                continue
                
            mother_idx = mother_idx[0]
            mother_genotype = state.chrom_a[mother_idx].sum().item()
            offspring_genotype = state.pending_offspring_chrom_a[i].sum().item()
            
            # Semelparous mother (2) should only produce semelparous offspring (2)
            if mother_genotype == 2 and offspring_genotype != 2:
                print(f"  ⚠️ Error: Semelparous mother (ID={mother_id}) "
                      f"produced offspring with genotype {offspring_genotype}")
            
            # Iteroparous mother (0) should not produce semelparous offspring (2)
            if mother_genotype == 0 and offspring_genotype == 2:
                print(f"  ⚠️ Error: Iteroparous mother (ID={mother_id}) "
                      f"produced semelparous offspring")
    
    def log_infection(self, state: SimulationState, t: int):
        """Logs information about infection"""
        if t % self.log_interval != 0:
            return
            
        n = state.pop_size
        if n == 0:
            return
            
        infected_mask = state.infection_stage[:n] > 0
        infected_count = infected_mask.sum().item()
        
        if infected_count > 0:
            print(f"\n=== INFECTION t={t} ===")
            print(f"Total infected: {infected_count}")
            
            # Analysis by stage
            for stage in [1, 3]:
                stage_mask = state.infection_stage[:n] == stage
                stage_count = stage_mask.sum().item()
                if stage_count > 0:
                    stage_indices = th.where(stage_mask)[0]
                    
                    # Durations
                    if stage == 1:
                        durations = state.stage1_duration[stage_indices]
                    else:
                        durations = state.stage3_duration[stage_indices]
                    
                    ages = state.age_of_disease[stage_indices]
                    
                    print(f"\nStage {stage}: {stage_count} individuals")
                    print(f"  Duration: min={durations.min():.0f}, "
                          f"max={durations.max():.0f}, mean={durations.mean():.0f}")
                    print(f"  Disease age: min={ages.min():.0f}, "
                          f"max={ages.max():.0f}, mean={ages.mean():.0f}")
    
    def check_semelparous_inheritance(self, state: SimulationState) -> None:
        """
        Checks correctness of semelparous trait inheritance.
        """
        n = state.pop_size
        if n == 0:
            return
        
        # Find parents and their offspring
        parent_ids = state.pending_offspring_mother_id[:state.pending_offspring_count]
        if len(parent_ids) == 0:
            return
        
        # For each unique parent
        unique_parents = th.unique(parent_ids)
        for parent_id in unique_parents:
            parent_idx = th.where(state.animal_ids == parent_id)[0]
            if len(parent_idx) == 0:
                continue
                
            parent_idx = parent_idx[0]
            parent_genotype = state.chrom_a[parent_idx].sum().item()
            
            # Find all offspring of this mother
            offspring_mask = parent_ids == parent_id
            offspring_indices = th.where(offspring_mask)[0]
            
            if len(offspring_indices) == 0:
                continue
                
            # Check offspring genotypes
            for off_idx in offspring_indices:
                offspring_genotype = state.pending_offspring_chrom_a[off_idx].sum().item()
                
                # Log inconsistencies
                if parent_genotype == 2:  # If parent is semelparous
                    if offspring_genotype != 2:  # Offspring should be semelparous
                        print(f"⚠️ Error: Semelparous parent (ID={parent_id}) "
                              f"produced offspring with genotype {offspring_genotype}")
                elif parent_genotype == 0:  # If parent is iteroparous
                    if offspring_genotype != 0:  # Offspring should be iteroparous
                        print(f"⚠️ Error: Iteroparous parent (ID={parent_id}) "
                              f"produced offspring with genotype {offspring_genotype}")
    
    def check_infection_stages_detailed(self, state: SimulationState, current_time: int) -> None:
        """
        Detailed check of infection stages.
        """
        n = state.pop_size
        if n == 0:
            return
        
        infected_mask = state.infection_stage[:n] > 0
        infected_indices = th.where(infected_mask)[0]
        
        if len(infected_indices) == 0:
            return
        
        print(f"\n=== DETAILED INFECTION CHECK AT t={current_time} ===")
        
        problems_found = 0
        for idx in infected_indices:
            stage = state.infection_stage[idx].item()
            age = state.age_of_disease[idx].item()
            stage1_dur = state.stage1_duration[idx].item()
            stage3_dur = state.stage3_duration[idx].item()
            
            if stage == 1:  # Latent stage
                # Check that duration is not exceeded
                if age > stage1_dur:
                    print(f"⚠️ Error: Individual {idx} in stage 1 for {age} days, "
                          f"but duration={stage1_dur}")
                    problems_found += 1
                
            elif stage == 3:  # Terminal stage
                total_duration = stage1_dur + stage3_dur
                age_in_stage3 = age - stage1_dur
                
                if age_in_stage3 < 0:
                    print(f"⚠️ Error: Negative time in stage 3 for individual {idx}")
                    problems_found += 1
                
                if age > total_duration:
                    print(f"⚠️ Error: Individual {idx} should have died: "
                          f"age={age} > total_duration={total_duration}")
                    problems_found += 1
        
        if problems_found == 0:
            print("✅ No problems detected with infection stage durations")
        
        # Check stage distribution
        stage1_count = (state.infection_stage[:n] == 1).sum().item()
        stage3_count = (state.infection_stage[:n] == 3).sum().item()
        print(f"Stage 1: {stage1_count}, Stage 3: {stage3_count}")